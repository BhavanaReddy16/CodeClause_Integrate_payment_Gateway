# Payment-Gateway-Integration--
Task 3 : Sparks Foundation Internship - Payment Gateway Integration 

Website Link :
https://boring-heisenberg-147679.netlify.app (Host the website at https://docs.netlify.com)

Payment gateway using By Razorpay.
Supports payments using credit/debit card , UPI , wallet , netbanking.
The payment gateway also sends a email and a receipt to the recipient's email-id
